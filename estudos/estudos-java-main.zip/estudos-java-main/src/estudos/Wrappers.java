package estudos;

public class Wrappers {

    public static void main(String[] args) {
        Byte b = 127; //byte

        Character c = 's'; //character

        Short sh = 32767; //short

        String s = "Uma sequência de caracters"; //string

        Float f = 1.4f; //float

        Integer i = 312456; //int

        Long l = 2333L; //long

        Double d = 1024.99; //double
    }
}
