package estudos;

public class TiposPrimitivos {
    public static void main(String[] args) throws Exception {
        byte b;
        byte b2 = 127;

        char c = 'A';
        char c2 = 14;

        short s = 32767;
        short s2 = -32768;

        int i = 2147483647;
        int i2 = -2147483648;

        long l = 9223372036854775807L;
        long l2 = -9223372036854775808L;

        float f = 65f;
        float f2 = -0.5f;

        double d = 1024.99;
        double d2 = 10.2456;

        boolean bo = true;
        boolean bo2 = false;

        System.out.println("Hello, World!");
    }
}
